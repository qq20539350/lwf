if( $('#postcomments').length ){
	$(document).on('click', function(e){
        e = e || window.event;
        var target = e.target || e.srcElement, _ta = $(target)

        if( _ta.hasClass('disabled') ) return
        if( _ta.parent().attr('data-type') ) _ta = $(_ta.parent()[0])
        if( _ta.parent().parent().attr('data-type') ) _ta = $(_ta.parent().parent()[0])

        var type = _ta.attr('data-type')

        switch( type ){
            case 'torespond':
            	scrollTo('#respond')
				$('#txaArticle').focus();

            break; case 'switch-author':
            	$('.comt-comterinfo').slideToggle(300);
				$('#inpName').focus();

            break; 
        }
    })

	$('.commentlist .url').attr('target','_blank')
	
/* 	$('#comment-author-info p input').focus(function() {
		$(this).parent('p').addClass('on')
	})
	$('#comment-author-info p input').blur(function() {
		$(this).parent('p').removeClass('on')
	}) */

	/* $('#txaArticle').focus(function(){
		if( $('#inpName').val()=='' || $('#inpEmail').val()=='' ) $('.comt-comterinfo').slideDown(300)
	}) */

	var edit_mode = '0',
		txt1 = '<div class="comt-tip comt-loading">正在提交, 请稍候...</div>',
		txt2 = '<div class="comt-tip comt-error">#</div>',
		txt3 = '">提交成功',
		cancel_edit = '取消编辑',
		edit,
		num = 1,
		comm_array = [];
	comm_array.push('');

	$comments = $('#comments-title');
	$cancel = $('#cancel-reply');
	cancel_text = $cancel.text();
	$submit = $('#commentform #submit');
	$submit.attr('disabled', false);
	$('.comt-tips').append(txt1 + txt2);
	$('.comt-loading').hide();
	$('.comt-error').hide();
	$body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $('html') : $('body')) : $('html,body');
	$('#commentform').submit(function() {
	var strFormAction=$("#inpId").parent("form").attr("action");
	var strName=$("#inpName").val();
	var strEmail=$("#inpEmail").val();
	var strHomePage=$("#inpHomePage").val();
	var strVerify=$("#inpVerify").val();
	var strArticle=$("#txaArticle").val();
	var intReplyID=$("#inpRevID").val();
	var intPostID=$("#inpId").val();
	var intMaxLen=200;
	if(strName==""){
		alert(lang_comment_name_error);
		return false;
	}
	else{
		re = new RegExp("^[\.\_A-Za-z0-9\u4e00-\u9fa5]+$");
		if (!re.test(strName)){
			alert(lang_comment_name_error);
			return false;
		}
	}

	if(strEmail==""){
		alert(lang_comment_email_error);
		return false;
	}
	else{
		re = new RegExp("^[\\w-]+(\\.[\\w-]+)*@[\\w-]+(\\.[\\w-]+)+$");
		if (!re.test(strEmail)){
			alert(lang_comment_email_error);
			return false;
		}
	}

	if(typeof(strArticle)=="undefined"){
		alert(lang_comment_content_error);
		return false;
	}

	if(typeof(strArticle)=="string"){
		if(strArticle==""){
			alert(lang_comment_content_error);
			return false;
		}
		if(strArticle.length>intMaxLen)
		{
			alert(lang_comment_content_error);
			return false;
		}
	}

	//ajax comment begin
	var strSubmit=$("#inpId").parent("form").find(":submit").val();
		$('.comt-loading').show();
		$submit.attr('disabled', true).fadeTo('slow', 0.5);
		if (edit) $('#txaArticle').after('<input type="text" name="edit_id" id="edit_id" value="' + edit + '" style="display:none;" />');
	$.post(strFormAction,{
		"isajax":true,
		"postid":intPostID,
		"verify":strVerify,
		"name":strName,		
		"email":strEmail,
		"content":strArticle,
		"homepage":strHomePage,
		"replyid":intReplyID},function(data) {
			var s =data;
			if((s.search("faultCode")>0)&&(s.search("faultString")>0)){
				alert(s.match("<string>.+?</string>")[0].replace("<string>","").replace("</string>",""))
				$('.comt-loading').hide();
				$submit.val(submit_val).attr('disabled', false).fadeTo('slow', 1);
				$('.comt-comterinfo').slideDown(300);
			}else{
				$('.comt-loading').hide();
				comm_array.push($('#txaArticle').val());
				$('textarea').each(function() {
					this.value = ''
				});
				var t = addComment,
				cancel = t.I('cancel-reply'),
				temp = t.I('wp-temp-form-div'),
				respond = t.I(t.respondId),
				post = t.I('inpId').value,
				parent = t.I('inpRevID').value;
				if (!edit && $comments.length) {
					n = parseInt($comments.text().match(/\d+/));
					$comments.text($comments.text().replace(n, n + 1))
				}
				new_htm = '" id="new_comm_' + num + '"></';
				new_htm = (parent == '0') ? ('\n<ol style="clear:both;" class="commentlist commentnew' + new_htm + 'ol>') : ('\n<ul class="children' + new_htm + 'ul>');
				ok_htm = '\n<span id="success_' + num + txt3;
				ok_htm += '</span><span></span>\n';

				if( parent == '0' ){
					if( $('#postcomments .commentlist').length ){
						$('#postcomments .commentlist').before(new_htm);
					}else{
						$('#respond').after(new_htm);
					}
				}else{
					$('#respond').after(new_htm);
				}

				$('#comment-author-info').slideUp()

				$('#new_comm_' + num).hide().append(data);
				$('#new_comm_' + num + ' li').append(ok_htm);
				$('#new_comm_' + num).fadeIn(4000);
				$body.animate({
					scrollTop: $('#new_comm_' + num).offset().top - 200
				},
				500);
				$('#new_comm_' + num).find('.c-avatar .avatar').attr('src', $('.comment .avatar').attr('data-src'));
				countdown();
				repajax();
				num++;
				edit = '';
				$('*').remove('#edit_id');
				cancel.style.display = 'none';
				cancel.onclick = null;
					$("#inpRevID").val(0);
				if (temp && respond) {
					temp.parentNode.insertBefore(respond, temp);
					temp.parentNode.removeChild(temp)
				}
			}
		});
				SaveRememberInfo();
				CommentComplete();
		return false
	});
	addComment = {
		moveForm: function(commId, parentId, respondId, postId, num) {
			$("#inpRevID").val(parentId);
			var t = this,
			div, comm = t.I(commId),
			respond = t.I(respondId),
			cancel = t.I('cancel-reply'),
			parent = t.I('inpRevID'),
			post = t.I('inpId');
			if (edit) exit_prev_edit();
			num ? (t.I('comment').value = comm_array[num], edit = t.I('new_comm_' + num).innerHTML.match(/(comment-)(\d+)/)[2], $new_sucs = $('#success_' + num), $new_sucs.hide(), $new_comm = $('#new_comm_' + num), $new_comm.hide(), $cancel.text(cancel_edit)) : $cancel.text(cancel_text);
			t.respondId = respondId;
			postId = postId || false;
			if (!t.I('wp-temp-form-div')) {
				div = document.createElement('div');
				div.id = 'wp-temp-form-div';
				div.style.display = 'none';
				respond.parentNode.insertBefore(div, respond)
			} ! comm ? (temp = t.I('wp-temp-form-div'), t.I('inpRevID').value = '0', temp.parentNode.insertBefore(respond, temp), temp.parentNode.removeChild(temp)) : comm.parentNode.insertBefore(respond, comm.nextSibling);
			$body.animate({scrollTop: $('#respond').offset().top - 180},400);
			if (post && postId) post.value = postId;
			parent.value = parentId;
			cancel.style.display = '';
			cancel.onclick = function() {
				if (edit) exit_prev_edit();
				var t = addComment,temp = t.I('wp-temp-form-div'),respond = t.I(t.respondId);
				$("#inpRevID").val(0);
				if (temp && respond) {
					temp.parentNode.insertBefore(respond, temp);
					temp.parentNode.removeChild(temp)
				}
				this.style.display = 'none';
				this.onclick = null;
				return false
			};
			try {
				t.I('txaArticle').focus()
			} catch(e) {}
			return false
		},
		I: function(e) {
			return document.getElementById(e)
		}
	};
	function exit_prev_edit() {
		$new_comm.show();
		$new_sucs.show();
		$('textarea').each(function() {
			this.value = ''
		});
		edit = ''
	}
	var wait = 15,
	submit_val = $submit.val();
	function countdown() {
		if (wait > 0) {
			$submit.val(wait);
			wait--;
			setTimeout(countdown, 1000)
		} else {
			$submit.val(submit_val).attr('disabled', false).fadeTo('slow', 1);
			wait = 15
		}
	}
	function repajax(){
	var tx=$('#new_comm_' + num).html();
	tx=tx.replace(/\[B\](.*)\[\/B\]/g,'<strong>$1</strong>');
	tx=tx.replace(/\[U\](.*)\[\/U\]/g,'<u>$1</u>');
	tx=tx.replace(/\[S\](.*)\[\/S\]/g,'<del>$1</del>');
	tx=tx.replace(/\[I\](.*)\[\/I\]/g,'<em>$1</em>');
	tx=tx.replace(/\[Q\](.*)\[\/Q\]/g,'<blockquote>$1</blockquote>');
	tx=tx.replace(/\[em_([A-Za-z0-9]*)\]/g,'<img src="'+ jsui.face + '/$1.gif" border="0" />');
	$('#new_comm_' + num).html(tx);
	
}
}