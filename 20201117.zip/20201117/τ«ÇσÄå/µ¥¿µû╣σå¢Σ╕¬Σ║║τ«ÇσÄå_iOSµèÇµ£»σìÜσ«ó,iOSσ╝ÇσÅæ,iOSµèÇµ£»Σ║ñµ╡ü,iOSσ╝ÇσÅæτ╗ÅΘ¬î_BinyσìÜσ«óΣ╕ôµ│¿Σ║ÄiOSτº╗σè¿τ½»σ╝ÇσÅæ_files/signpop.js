define(function (){

return {
	init: function (){
		var signHtml = '\
			<div class="sign">\
			    <div class="sign-mask"></div>\
			    <div class="container">\
			        <a href="#" class="close-link signclose-loader"><i class="fa fa-close"></i></a>\
			        <div class="sign-tips"></div>\
			        <form id="sign-in" method="post" action="'+jsui.www+'zb_system/cmd.php?act=verify">  \
				<input type="hidden" name="username" id="username" value="" />\
	<input type="hidden" name="password" id="password" value="" />\
	<input type="hidden" name="savedate" id="savedate" value="0" />\
			            <h3>'+(jsui.signup ? jsui.signup : '')+'登录</h3>\
			            <h6>\
			                <label for="inputEmail">用户名</label>\
			                <input type="text" name="edtUserName" tabindex="1" required="required" checked="checked" class="form-control" id="edtUserName" placeholder="用户名">\
			            </h6>\
			            <h6>\
			                <label for="inputPassword">密码</label>\
			                <input type="password" name="edtPassWord" tabindex="2" required="required" checked="checked" class="form-control" id="edtPassWord" placeholder="登录密码">\
			            </h6>\
			            <div class="sign-submit">\
			                <input type="submit" tabindex="4" class="btn btn-primary signsubmit-loader" id="btnPosts" name="btnPosts" value="登 陆">  \
			                <label><input type="checkbox" id="chkRemember" tabindex="3" name="chkRemember">记住我</label>\
			            </div>\
						<div class="sign-info"><a href="'+jsui.www+'">找回密码？</a></div>\
					<div class="sign-social">\
					'+(jsui.qqlogin ? jsui.qqlogin : '')+'\
					<!--<a class="login-weibo" href=""><i class="fa fa-weibo"></i> 微博登陆</a>-->\
					</div>\
			        </form>\
			    </div>\
			</div>\
		'

	    jsui.bd.append( signHtml );

 	    $('.signin-loader').on('click', function(){
	    	jsui.bd.addClass('sign-show')
	    	setTimeout(function(){
            	$('#sign-in').show().find('input:first').focus()
            }, 300);
	    }) 
		$('.sign-mask').on('click', function(){
	    	jsui.bd.removeClass('sign-show')
	    })
		$('.signclose-loader').on('click', function(){
	    	jsui.bd.removeClass('sign-show')
	    })

		 $("#btnPosts").click(function(){
            var strUserName=$("#edtUserName").val();
            var strPassWord=$("#edtPassWord").val();
            var strSaveDate=$("#savedate").val()
            if((strUserName=="")||(strPassWord=="")){
                alert("用户名和密码不能为空");
                return false;
            }
            $("#username").val(strUserName);
            $("#password").val(MD5(strPassWord));
            $("#savedate").val(strSaveDate);
        })
        $("#chkRemember").click(function(){
            $("#savedate").attr("value",$("#chkRemember").attr("checked")=="checked"?30:0);
        })
	}
}

})